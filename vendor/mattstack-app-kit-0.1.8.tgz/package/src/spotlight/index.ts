export * from '@mantine/spotlight';
