import { type ComponentPropsWithoutRef, type ElementType, forwardRef, type Ref } from 'react';
import type { ResolvedTheme } from '../theme/index.ts';
import { autoVars } from './auto-vars.ts';
import { buildDataAttrs } from './data-attrs.ts';
import { useProps } from './hooks/use-props.ts';
import { useStyles } from './hooks/use-styles.ts';
import { makeExtendEntry } from './make-extend-entry.ts';
import { attachRecipeMeta } from './recipe-meta.ts';
import type { UniversalStyleProps } from './style-props/style-props.types.ts';
import { useStyleProps } from './style-props/use-style-props.tsx';
import type { ThemeComponentEntry } from './theme-component-entry.ts';
import type { ComponentExtendConfig } from './types/component-extend.ts';
import type { FactoryPayload } from './types/factory-payload.ts';
import type { PolymorphicComponentProps } from './types/polymorphic.ts';
import type { StylesApiProps } from './types/props.ts';
import type { GetStylesFn } from './types/render-context.ts';
import type {
  InjectedVocabularyProps,
  VariantProp,
  VocabularyAxis,
} from './types/vocabulary-axes.ts';
import { validateVocabularyProps } from './validate-vocabulary-props.ts';
import { makeWithProps } from './with-props.tsx';

/**
 * Render-context type for polymorphic recipes (e.g., Button). Authors type
 * their `render` function's parameter via this so destructuring is fully typed
 * — no `as` casts needed inside the render body.
 *
 * `props` is the intersection of:
 *   - `TOwnProps` — the recipe's own prop interface
 *   - `StylesApiProps<TPayload>` — framework keys (className, style, classNames,
 *     styles, vars, attributes, unstyled) typed against the factory payload, NOT
 *     `<any>`. Destructuring these gives proper types.
 *   - `Omit<ComponentPropsWithoutRef<TDefaultAs>, ...>` — HTML attributes for the
 *     default element (e.g., `disabled` / `onClick` for `<button>`). The `Omit`
 *     guards against TOwnProps overrides for shared keys.
 *   - variant / intent — populated by `useProps` from theme + recipe defaults.
 *
 * The `...rest` after destructuring TOwnProps + framework keys is structurally
 * `ComponentPropsWithoutRef<TDefaultAs>`-compatible, so spreading on `<Element>`
 * works without an index-signature cast.
 *
 * Resolves the Wave 1 Gap 2 "documented convention" — the cast block is gone;
 * destructuring is the only remaining boilerplate (kept per the composition
 * rationale: recipes wrapping inner primitives need to forward framework keys).
 */
export type PolymorphicRenderCtx<
  TOwnProps,
  TDefaultAs extends ElementType,
  TSelectors extends readonly string[] = readonly string[],
  TVariants extends readonly string[] = readonly string[],
  TVocabAxes extends readonly VocabularyAxis[] = readonly [],
> = {
  Element: ElementType;
  props: TOwnProps &
    InjectedVocabularyProps<TVocabAxes> &
    StylesApiProps<{ props: TOwnProps; stylesNames: TSelectors[number] } & FactoryPayload> &
    Omit<
      ComponentPropsWithoutRef<TDefaultAs>,
      keyof TOwnProps | keyof StylesApiProps<FactoryPayload>
    > & { variant?: TVariants[number]; intent?: string };
  getStyles: GetStylesFn<{ props: TOwnProps; stylesNames: TSelectors[number] } & FactoryPayload>;
  ref: Ref<unknown>;
};

export interface DefinePolymorphicComponentConfig<
  TOwnProps,
  TDefaultAs extends ElementType,
  TSelectors extends readonly string[],
  TVariants extends readonly string[],
  TVocabAxes extends readonly VocabularyAxis[] = readonly [],
> {
  name: string;
  defaultElement: TDefaultAs;
  vocabularyAxes?: TVocabAxes;
  selectors: TSelectors;
  variants?: TVariants;
  classes?: Partial<Record<TSelectors[number], string>>;
  defaults?: Partial<
    NoInfer<TOwnProps> & InjectedVocabularyProps<TVocabAxes> & VariantProp<TVariants>
  >;
  vars?: (
    theme: ResolvedTheme,
    props: TOwnProps & { variant?: TVariants[number]; intent?: string },
  ) => Partial<Record<TSelectors[number], Record<string, string>>>;
  render: (
    ctx: PolymorphicRenderCtx<TOwnProps, TDefaultAs, TSelectors, TVariants, TVocabAxes>,
  ) => React.ReactNode;
}

/**
 * Polymorphic component definition with `as` prop support.
 */
export function definePolymorphicComponent<
  TOwnProps,
  TDefaultAs extends ElementType,
  TSelectors extends readonly string[] = readonly string[],
  TVariants extends readonly string[] = readonly string[],
  TVocabAxes extends readonly VocabularyAxis[] = readonly [],
>(
  config: DefinePolymorphicComponentConfig<
    TOwnProps,
    TDefaultAs,
    TSelectors,
    TVariants,
    TVocabAxes
  >,
) {
  const hasVariants = (config.variants?.length ?? 0) > 0;

  const Component = forwardRef<unknown, any>((rawProps, ref) => {
    const merged = useProps<TOwnProps & StylesApiProps<any>>(
      config.name,
      (config.defaults ?? null) as Partial<TOwnProps & StylesApiProps<any>> | null,
      rawProps as TOwnProps & StylesApiProps<any>,
    );

    // `as` resolves AFTER useProps (Mantine semantics) so theme defaultProps
    // can retarget the element; stripping it here keeps it off the DOM.
    const { as: asProp, ...rest } = merged as { as?: ElementType };
    const Element: ElementType = asProp ?? config.defaultElement;

    const sp = useStyleProps(rest as Record<string, unknown>);

    validateVocabularyProps(config.name, config.vocabularyAxes ?? [], sp.rest, config.variants);

    const varsResolver = config.vars
      ? (theme: ResolvedTheme, props: any) => config.vars!(theme, props)
      : (theme: ResolvedTheme, props: any) =>
          autoVars(theme, config.name, props, hasVariants) as any;

    const getStyles = useStyles<
      { props: TOwnProps; stylesNames: TSelectors[number] } & FactoryPayload
    >({
      name: config.name,
      classes: config.classes as any,
      className: (sp.rest as any).className,
      style: (sp.rest as any).style,
      classNames: (sp.rest as any).classNames,
      styles: (sp.rest as any).styles,
      vars: (sp.rest as any).vars,
      attributes: (sp.rest as any).attributes,
      unstyled: (sp.rest as any).unstyled,
      dataAttrs: buildDataAttrs(config.vocabularyAxes ?? [], hasVariants, sp.rest),
      props: sp.rest as any,
      varsResolver: varsResolver as any,
      stylePropsStyle: sp.rootStyle as any,
      stylePropsClassName: sp.rootClassName,
    });

    const rendered = config.render({
      Element,
      props: sp.rest as any,
      getStyles: getStyles as any,
      ref,
    }) as React.ReactElement;

    return sp.styleNode ? (
      <>
        {sp.styleNode}
        {rendered}
      </>
    ) : (
      rendered
    );
  });

  Component.displayName = config.name;
  attachRecipeMeta(Component, {
    builder: 'definePolymorphicComponent',
    name: config.name,
    slots: config.selectors,
    parts: [],
    vocabularyAxes: config.vocabularyAxes ?? [],
    variants: config.variants ?? [],
    defaults: config.defaults ?? {},
  });
  (Component as any).__vocabularyAxes = config.vocabularyAxes ?? [];
  (Component as any).classes = config.classes;
  (Component as any).withProps = makeWithProps(Component as any);
  type DefinePolymorphicProps = TOwnProps &
    StylesApiProps<any> &
    Omit<
      ComponentPropsWithoutRef<TDefaultAs>,
      keyof TOwnProps | keyof StylesApiProps<FactoryPayload>
    > & { variant?: TVariants[number]; intent?: string };

  (Component as any).extend = makeExtendEntry<DefinePolymorphicProps>(config.name);

  return Component as unknown as PolymorphicComponentResult<
    TOwnProps,
    TDefaultAs,
    TSelectors,
    TVariants,
    TVocabAxes
  >;
}

/**
 * Public call-site props of a raw polymorphic recipe: own props, declared
 * vocabulary axes (string-typed; theme-narrowed via makeBuilders), the
 * recipe's variant tuple, and the selector-keyed styles API.
 */
/**
 * `TExtra` is the theme-narrowing hook: the themed builder instantiates it
 * with `ThemedVocabularyProps<TVocab, TVocabAxes>` so global axes intersect
 * down from `string` to the theme's literal unions.
 */
export type PolymorphicPublicProps<
  TOwnProps,
  TSelectors extends readonly string[],
  TVariants extends readonly string[],
  TVocabAxes extends readonly VocabularyAxis[],
  TExtra = unknown,
> = TOwnProps &
  InjectedVocabularyProps<TVocabAxes> &
  VariantProp<TVariants> &
  TExtra &
  StylesApiProps<{ props: TOwnProps; stylesNames: TSelectors[number] } & FactoryPayload> &
  UniversalStyleProps;

type PolymorphicExtendProps<
  TOwnProps,
  TDefaultAs extends ElementType,
  TSelectors extends readonly string[],
  TVariants extends readonly string[],
  TVocabAxes extends readonly VocabularyAxis[],
  TExtra = unknown,
> = PolymorphicPublicProps<TOwnProps, TSelectors, TVariants, TVocabAxes, TExtra> &
  Omit<
    ComponentPropsWithoutRef<TDefaultAs>,
    keyof TOwnProps | keyof StylesApiProps<FactoryPayload>
  > & {
    /**
     * A theme's `defaultProps` may retarget the rendered element, which this
     * builder already implements and pins with a runtime test: `as` is
     * resolved AFTER `useProps` merges theme defaults in, and stripped before
     * render. It belongs in the type for the same reason — without it,
     * `.extend({ defaultProps: { as: 'button' } })` failed excess-property
     * checking (TS2353) on a config the runtime honours.
     */
    as?: ElementType;
    variant?: TVariants[number];
    intent?: string;
  };

/**
 * The component value produced by a `definePolymorphicComponent` call.
 * Generic over the target element at the call site (`as="span"` narrows props
 * to span attributes); `withProps` returns the same shape so static chains
 * (`.withProps().withProps()`, `.withProps().extend()`) keep type-checking.
 */
export type PolymorphicComponentResult<
  TOwnProps,
  TDefaultAs extends ElementType,
  TSelectors extends readonly string[],
  TVariants extends readonly string[],
  TVocabAxes extends readonly VocabularyAxis[],
  TExtra = unknown,
> = (<TAs extends ElementType = TDefaultAs>(
  props: PolymorphicComponentProps<
    TAs,
    PolymorphicPublicProps<TOwnProps, TSelectors, TVariants, TVocabAxes, TExtra>
  >,
) => React.ReactElement | null) & {
  withProps: <TAs extends ElementType = TDefaultAs>(
    presets: Partial<
      PolymorphicPublicProps<TOwnProps, TSelectors, TVariants, TVocabAxes, TExtra>
    > & {
      as?: TAs;
    },
  ) => PolymorphicComponentResult<TOwnProps, TDefaultAs, TSelectors, TVariants, TVocabAxes, TExtra>;
  extend: (
    config: ComponentExtendConfig<
      PolymorphicExtendProps<TOwnProps, TDefaultAs, TSelectors, TVariants, TVocabAxes, TExtra>
    >,
  ) => ThemeComponentEntry<
    PolymorphicExtendProps<TOwnProps, TDefaultAs, TSelectors, TVariants, TVocabAxes, TExtra>
  >;
  classes?: Partial<Record<TSelectors[number], string>>;
  displayName?: string;
};
